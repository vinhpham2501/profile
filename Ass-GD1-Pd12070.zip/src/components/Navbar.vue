<template>
  <nav class="navbar">
    <div class="nav-container container-xl">
      <div class="nav-brand d-flex align-items-center gap-2">
        <img src="/images/logoo.png" alt="Logo" style="height:28px;width:auto;border-radius:6px" onerror="this.style.display='none'" />
        <span class="brand-text">Portfolio</span>
      </div>
      <div class="nav-menu d-none d-md-flex">
        <a href="#home" class="nav-link active">Home</a>
        <a href="#about" class="nav-link">About</a>
        <a href="#skills" class="nav-link">Skills</a>
        <a href="#services" class="nav-link">Services</a>
        <a href="#portfolio" class="nav-link">Project</a>
        <a href="#contact" class="nav-link">Contact</a>
      </div>
      <button class="mobile-menu-btn d-md-none btn"><i class="fas fa-bars"></i></button>
    </div>
  </nav>
</template>

<script setup lang="ts">
import { onMounted } from 'vue'

onMounted(() => {
  // simple mobile toggle using Bootstrap utility classes
  const btn = document.querySelector('.mobile-menu-btn')
  const menu = document.querySelector('.nav-menu')
  btn?.addEventListener('click', () => menu?.classList.toggle('d-none'))
})
</script>
