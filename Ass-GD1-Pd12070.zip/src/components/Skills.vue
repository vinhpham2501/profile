<template>
  <section id="skills" class="skills">
    <div class="container">
      <h2 class="section-title text-center">My <span class="highlight">Skills</span></h2>
      <div class="skills-grid">
        <div class="skill-card"><i class="fab fa-html5 skill-icon" /><h3>HTML</h3><p>Semantic markup, forms.</p></div>
        <div class="skill-card"><i class="fab fa-css3-alt skill-icon" /><h3>CSS</h3><p>Flexbox, Grid, animations.</p></div>
        <div class="skill-card"><i class="fab fa-js skill-icon" /><h3>JavaScript</h3><p>ES6+, fetch API.</p></div>
        <div class="skill-card"><i class="fab fa-php skill-icon" /><h3>PHP</h3><p>Server-side basics.</p></div>
        <div class="skill-card"><i class="fas fa-globe skill-icon" /><h3>SEO</h3><p>Meta tags, performance.</p></div>
        <div class="skill-card"><i class="fas fa-paint-brush skill-icon" /><h3>Design</h3><p>UI/UX, color & layout.</p></div>
        <div class="skill-card"><i class="fab fa-python skill-icon" /><h3>Python</h3><p>Scripting, Flask.</p></div>
        <div class="skill-card"><i class="fab fa-react skill-icon" /><h3>React</h3><p>Hooks, components.</p></div>
      </div>
    </div>
  </section>
</template>

<script setup lang="ts">
</script>
