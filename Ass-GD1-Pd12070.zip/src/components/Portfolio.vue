<template>
  <section id="portfolio" class="portfolio">
    <div class="container">
      <h2 class="section-title text-center">Latest <span class="highlight">Project</span></h2>
      <div class="portfolio-grid">
        <div class="portfolio-item">
          <img src="https://images.unsplash.com/photo-1461749280684-dccba630e2f6?auto=format&fit=crop&w=800&h=600" alt="Web Project" />
          <div class="portfolio-overlay"><h3>Web Development Project</h3><p>Modern responsive portfolio.</p></div>
        </div>
        <div class="portfolio-item">
          <img src="https://images.unsplash.com/photo-1561070791-2526d30994b5?auto=format&fit=crop&w=800&h=600" alt="UX/UI" />
          <div class="portfolio-overlay"><h3>UX/UI Design Project</h3><p>User-centered interface.</p></div>
        </div>
        <div class="portfolio-item">
          <img src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=800&h=600" alt="Data" />
          <div class="portfolio-overlay"><h3>Analytics Dashboard</h3><p>Interactive visualization.</p></div>
        </div>
      </div>
    </div>
  </section>
</template>

<script setup lang="ts">
</script>
