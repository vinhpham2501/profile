<script setup lang="ts">
import { onMounted } from 'vue'
import Navbar from './components/Navbar.vue'
import Hero from './components/Hero.vue'
import About from './components/About.vue'
import Skills from './components/Skills.vue'
import Portfolio from './components/Portfolio.vue'
import Contact from './components/Contact.vue'
import Services from './components/Services.vue'
import Footer from './components/Footer.vue'

onMounted(() => {
  const links = Array.from(document.querySelectorAll<HTMLAnchorElement>('.nav-link'))
  const sections = Array.from(document.querySelectorAll<HTMLElement>('section'))
  const setActive = () => {
    const y = scrollY + 100
    sections.forEach(s => {
      const id = s.id; if (y >= s.offsetTop && y < s.offsetTop + s.offsetHeight) {
        links.forEach(a => a.classList.toggle('active', a.getAttribute('href') === `#${id}`))
      }
    })
  }
  addEventListener('scroll', setActive); setActive()
})
</script>

<template>
  <Navbar />
  <Hero />
  <About />
  <Skills />
  <Services />
  <Portfolio />
  <Contact />
  <Footer />
</template>

<style scoped>
/* components are styled globally in style.css */
</style>
